#!/usr/bin/env python3

import math
import random
from typing import Dict, List, Tuple

import rclpy
from rclpy.qos import qos_profile_sensor_data
from rclpy.node import Node

from px4_msgs.msg import VehicleLocalPosition, TrajectorySetpoint
from geometry_msgs.msg import Twist

from enum import IntEnum, unique
from ros2swarm.utils import setup_node
from ros2swarm.movement_pattern.movement_pattern import MovementPattern
from ros2swarm.utils.state import State


def euclidean_distance(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)


def check_robot(min_range, max_range, current_ranges, threshold):
    count = sum([1 for d in current_ranges if min_range < d < max_range])
    return count if count < threshold else 0


def convert_twist_to_trajectory_setpoint(twist_msg: Twist, timestamp: int) -> TrajectorySetpoint:
    msg = TrajectorySetpoint()
    msg.timestamp = timestamp
    msg.position = [float('nan'), float('nan'), float('nan')]
    msg.velocity = [twist_msg.linear.x, twist_msg.linear.y, twist_msg.linear.z]
    msg.yaw = twist_msg.angular.z
    return msg


@unique
class Directions(IntEnum):
    FRONT = 0
    LEFT = 1
    BEHIND = 2
    RIGHT = 3


def classify_neighbors(self_pose: Tuple[float, float, float], heading: float,
                       neighbor_poses: List[Tuple[float, float, float]]) -> Dict[Directions, List[float]]:
    x_self, y_self, _ = self_pose
    zones = {d: [] for d in Directions}

    for (x_n, y_n, _) in neighbor_poses:
        dx = x_n - x_self
        dy = y_n - y_self
        distance = math.sqrt(dx ** 2 + dy ** 2)
        angle = math.atan2(dy, dx) - heading
        angle = (angle + math.pi) % (2 * math.pi) - math.pi

        if -math.pi / 4 <= angle < math.pi / 4:
            zones[Directions.FRONT].append(distance)
        elif math.pi / 4 <= angle < 3 * math.pi / 4:
            zones[Directions.LEFT].append(distance)
        elif -3 * math.pi / 4 <= angle < -math.pi / 4:
            zones[Directions.RIGHT].append(distance)
        else:
            zones[Directions.BEHIND].append(distance)

    return zones


class MinimalistFlockingPattern(MovementPattern):

    def __init__(self):
        super().__init__('minimalist_flocking_pattern')

        self.declare_parameters(namespace='', parameters=[
            ('minimalist_flocking_translational_velocity', 0.5),
            ('minimalist_flocking_rotational_left_velocity', 0.5),
            ('minimalist_flocking_rotational_right_velocity', -0.5),
            ('minimalist_flocking_drive_timer_period', 10),
            ('minimalist_flocking_zone1_threshold', 2.0),
            ('minimalist_flocking_zone2_threshold', 4.0),
            ('minimalist_flocking_zone3_threshold', 6.0),
            ('minimalist_flocking_zone4_threshold', 8.0),
            ('minimalist_flocking_zone2_robot_threshold', 2),
            ('minimalist_flocking_robot_threshold', 3),
            ('max_range', 10.0),
            ('min_range', 0.1)
        ])

        self.state = State.INIT
        self.counter = 0
        self.current_pose = None  # Tuple[float, float, float]
        self.neighbor_poses: Dict[str, Tuple[float, float, float]] = {}
        self.ranges = {d: [] for d in Directions}

        self.pose_sub = self.create_subscription(
            VehicleLocalPosition,
            self.get_namespace() + '/fmu/out/vehicle_local_position',
            self.pose_callback,
            qos_profile_sensor_data
        )

        self.command_publisher = self.create_publisher(
            TrajectorySetpoint,
            self.get_namespace() + '/fmu/in/trajectory_setpoint',
            qos_profile_sensor_data
        )

        # Subscribe to neighbor poses from px4_2 and px4_3
        for ns in ['px4_2', 'px4_3']:
            self.create_subscription(
                VehicleLocalPosition,
                f'/{ns}/fmu/out/vehicle_local_position',
                self.make_neighbor_callback(ns),
                qos_profile_sensor_data
            )

        self.param_translational_velocity = self.get_parameter(
            "minimalist_flocking_translational_velocity").get_parameter_value().double_value
        self.param_rotational_left_velocity = self.get_parameter(
            "minimalist_flocking_rotational_left_velocity").get_parameter_value().double_value
        self.param_rotational_right_velocity = self.get_parameter(
            "minimalist_flocking_rotational_right_velocity").get_parameter_value().double_value
        self.param_drive_timer_period = self.get_parameter(
            "minimalist_flocking_drive_timer_period").get_parameter_value().integer_value
        self.param_zone1_threshold = self.get_parameter(
            "minimalist_flocking_zone1_threshold").get_parameter_value().double_value
        self.param_zone2_threshold = self.get_parameter(
            "minimalist_flocking_zone2_threshold").get_parameter_value().double_value
        self.param_zone3_threshold = self.get_parameter(
            "minimalist_flocking_zone3_threshold").get_parameter_value().double_value
        self.param_zone4_threshold = self.get_parameter(
            "minimalist_flocking_zone4_threshold").get_parameter_value().double_value
        self.param_zone2_robot_threshold = self.get_parameter(
            "minimalist_flocking_zone2_robot_threshold").get_parameter_value().integer_value
        self.param_robot_threshold = self.get_parameter(
            "minimalist_flocking_robot_threshold").get_parameter_value().integer_value
        self.param_max_range = self.get_parameter("max_range").get_parameter_value().double_value
        self.param_min_range = self.get_parameter("min_range").get_parameter_value().double_value

        self.move = Twist()
        self.move.linear.x = self.param_translational_velocity

    def make_neighbor_callback(self, ns):
        def callback(msg):
            self.neighbor_poses[ns] = (msg.x, msg.y, msg.z)
            self.get_logger().info(f"[INFO] Retrieved neighbor info from drone_{ns}")
            self.evaluate_behavior()
        return callback

    def pose_callback(self, msg):
        self.current_pose = (msg.x, msg.y, msg.z)

    def evaluate_behavior(self):
        if not self.current_pose or not self.neighbor_poses:
            return

        self.ranges = classify_neighbors(self.current_pose, 0.0, list(self.neighbor_poses.values()))
        self.direction = self.vector_calc()

        ts_msg = convert_twist_to_trajectory_setpoint(
            self.direction, self.get_clock().now().nanoseconds // 1000)
        self.command_publisher.publish(ts_msg)

    def robot_detect(self):
        obstacle = [False, False, False]
        headings = [math.radians(90), 0.0, math.radians(-90)]
        for i, heading in enumerate(headings):
            count = 0
            for np in self.neighbor_poses.values():
                dx = np[0] - self.current_pose[0]
                dy = np[1] - self.current_pose[1]
                angle = math.atan2(dy, dx)
                dist = math.sqrt(dx**2 + dy**2)
                angle_diff = abs(math.atan2(math.sin(angle - heading), math.cos(angle - heading)))
                if dist < self.param_zone2_threshold and angle_diff < math.pi / 6:
                    count += 1
            obstacle[i] = (1 < count < self.param_zone2_robot_threshold)
        return obstacle

    def vector_calc(self):
        self.counter += 1
        obstacle = self.robot_detect()

        if self.state is State.AVOID:
            behave = self.collision_avoid()
            self.state = State.AVOID
        elif self.state is State.DISPERSION or (self.state is State.INIT and any(obstacle)):
            behave = self.separation()
            self.state = State.DISPERSION
        elif self.state is State.ATTRACTION or (self.state is State.INIT and (
            check_robot(self.param_zone3_threshold, self.param_max_range,
                        self.ranges[Directions.LEFT], self.param_robot_threshold) or
            check_robot(self.param_zone3_threshold, self.param_max_range,
                        self.ranges[Directions.RIGHT], self.param_robot_threshold))):
            behave = self.cohesion()
            self.state = State.ATTRACTION
        elif self.state is State.ATTRACTION_BACK or (self.state is State.INIT and
            check_robot(self.param_zone4_threshold, self.param_max_range,
                        self.ranges[Directions.BEHIND], self.param_robot_threshold)):
            behave = self.cohesion_behind()
            self.state = State.ATTRACTION_BACK
        else:
            behave = self.move
            self.counter = 0

        if self.counter >= self.param_drive_timer_period:
            self.state = State.INIT
            self.counter = 0

        return behave

    def collision_avoid(self):
        return Twist(linear=Twist().linear.__class__(x=-0.5))

    def separation(self):
        twist = Twist()
        obstacle = self.robot_detect()
        if obstacle[0]:
            twist.angular.z = self.param_rotational_right_velocity
        elif obstacle[1]:
            twist.angular.z = random.choice([self.param_rotational_left_velocity,
                                             self.param_rotational_right_velocity])
        elif obstacle[2]:
            twist.angular.z = self.param_rotational_left_velocity
        else:
            twist.linear.x = self.param_translational_velocity
        return twist

    def cohesion(self):
        left, right = 0, 0
        for np in self.neighbor_poses.values():
            dx = np[0] - self.current_pose[0]
            dy = np[1] - self.current_pose[1]
            angle = math.atan2(dy, dx)
            dist = math.sqrt(dx ** 2 + dy ** 2)
            if self.param_zone3_threshold < dist < self.param_max_range:
                if -math.pi / 2 < angle <= 0:
                    left += 1
                elif 0 < angle < math.pi / 2:
                    right += 1
        twist = Twist()
        if left == right:
            twist.linear.x = self.param_translational_velocity
        elif left > right:
            twist.angular.z = self.param_rotational_left_velocity
        else:
            twist.angular.z = self.param_rotational_right_velocity
        return twist

    def cohesion_behind(self):
        behind_count = 0
        for np in self.neighbor_poses.values():
            dx = np[0] - self.current_pose[0]
            dy = np[1] - self.current_pose[1]
            angle = math.atan2(dy, dx)
            dist = math.sqrt(dx ** 2 + dy ** 2)
            if self.param_zone4_threshold < dist < self.param_max_range and abs(angle) > 2 * math.pi / 3:
                behind_count += 1
        twist = Twist()
        if behind_count:
            twist.angular.z = self.param_rotational_left_velocity
        else:
            twist.linear.x = self.param_translational_velocity
        return twist


def main(args=None):
    setup_node.init_and_spin(args, MinimalistFlockingPattern)


if __name__ == '__main__':
    main()

