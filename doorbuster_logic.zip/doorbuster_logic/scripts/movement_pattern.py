#Modified for ROS2 Foxy and PX4 modularity by Siddhant Baroth, 2025.
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from px4_msgs.msg import TrajectorySetpoint
from geometry_msgs.msg import Twist


class MovementPattern(Node):
    """Base class for movement patterns that publish PX4 TrajectorySetpoints."""

    def __init__(self, node_name: str):
        """
        Initialize the pattern node and its command publisher.
        """
        super().__init__(node_name)
        self.command_publisher = self.create_publisher(
            TrajectorySetpoint,
            self.get_namespace() + '/fmu/in/trajectory_setpoint',
            qos_profile_sensor_data
        )

    def publish_movement(self, twist: Twist):
        """
        Convert Twist to TrajectorySetpoint and publish.
        """
        ts_msg = self.convert_twist_to_trajectory_setpoint(
            twist, self.get_clock().now().nanoseconds // 1000)
        self.command_publisher.publish(ts_msg)

    def swarm_command_false_case(self):
        """
        Stop movement by sending a zero Twist command.
        """
        self.publish_movement(Twist())

    def destroy_node(self):
        """
        Stop movement and cleanup the node.
        """
        self.publish_movement(Twist())
        super().destroy_node()

    @staticmethod
    def convert_twist_to_trajectory_setpoint(twist_msg: Twist, timestamp: int) -> TrajectorySetpoint:
        """
        Convert a Twist message to a PX4-compatible TrajectorySetpoint.

        Parameters:
            twist_msg (Twist): Linear and angular velocity commands.
            timestamp (int): Current ROS time in microseconds.

        Returns:
            TrajectorySetpoint: Ready for PX4 offboard publishing.
        """
        msg = TrajectorySetpoint()
        msg.timestamp = timestamp
        msg.position = [float('nan')] * 3
        msg.velocity = [twist_msg.linear.x,twist_msg.linear.y,twist_msg.linear.z]
        msg.yaw = twist_msg.angular.z
        return msg
