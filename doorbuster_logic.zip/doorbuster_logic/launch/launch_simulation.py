#!/usr/bin/env python3

__author__ = "Arthur Astier"

import json
import os
from launch import LaunchDescription
from launch.actions import TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def parse_swarm_config(config_file):
    model_counts = {}
    swarm_config = config_file["swarm"]
    for key, item in swarm_config.items():
        model = item["model"]
        model_counts[model] = model_counts.get(model, 0) + 1

    script = ""
    for key, item in model_counts.items():
        script += key + ":" + str(item) + ","
    script = script[:-1]

    initial_poses_string = "\""
    initial_poses_dict = {}
    for idx, item in enumerate(swarm_config.values()):
        initial_pose = item["initial_pose"]
        initial_poses_dict["px4_" + str(idx + 1)] = initial_pose
        initial_poses_string += str(initial_pose["x"]) + "," + str(initial_pose["y"]) + "|"
    initial_poses_string = initial_poses_string[:-1] + "\""

    is_leaders = [item["is_leader"] for item in swarm_config.values()]

    return len(swarm_config), script, initial_poses_string, initial_poses_dict, is_leaders, config_file["trajectory"]


def generate_launch_description():
    ld = LaunchDescription()
    package_dir = get_package_share_directory('px4_swarm_controller')

    with open(os.path.join(package_dir, 'config', 'swarm_config.json'), 'r') as swarm_file:
        swarm_config_data = json.load(swarm_file)

    nb_drones, script, initial_poses, initial_poses_dict, is_leaders, trajectory = parse_swarm_config(swarm_config_data)

    with open(os.path.join(package_dir, 'config', 'control_config.json'), 'r') as control_file:
        control_config = json.load(control_file)

    neighborhood = control_config["neighborhood"]
    neighbors_exe = neighborhood["neighbors_exe"]
    neighbors_distance = neighborhood["neighbor_distance"]
    neighbors_params = neighborhood["params"]

    controller_info = control_config["controller"]
    controller_exe = controller_info["controller_exe"]
    controller_params = controller_info["params"]
    is_leader_follower_control = controller_info["leader_follower"]

    if is_leader_follower_control:
        neighbors_params = {"leaders": is_leaders, **neighbors_params}
    else:
        is_leaders = [False for _ in is_leaders]

    ld.add_action(
        Node(
            package='px4_swarm_controller',
            executable='simulation_node.py',
            name='simulation_node',
            parameters=[{'script': script, 'initial_pose': initial_poses}]
        )
    )

    xs_init = []
    ys_init = []

    for (namespace, initial_pose), aleader in zip(initial_poses_dict.items(), is_leaders):
        xs_init.append(initial_pose["y"])
        ys_init.append(initial_pose["x"])

        if aleader:
            ld.add_action(Node(
                package='px4_swarm_controller',
                executable='waypoint',
                name='waypoint',
                namespace=namespace,
                parameters=[
                    {"wp_path": os.path.join(package_dir, "config", "Trajectories", trajectory),
                     "x_init": initial_pose["x"], "y_init": initial_pose["y"]}
                ]
            ))
        else:
            ld.add_action(Node(
                package='px4_swarm_controller',
                executable='flocky',  # must match actual installed script name
                name='mini_flock',
                namespace=namespace,
                parameters=[
                    {"x_init": initial_pose["x"], "y_init": initial_pose["y"]}
                ],
                output='screen'
            ))

        # Arm each drone individually
    
    ld.add_action(TimerAction(
    period=10.0,
    actions=[Node(
        package='px4_swarm_controller',
        executable='arming',
        name='arming',
        namespace='simulation',
        parameters=[{"nb_drones": nb_drones}]
    )]
))

    return ld
